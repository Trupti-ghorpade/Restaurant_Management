//NAME: Sakshi Sharad Gaikwad
//URN: 1022032021
//ROLL NO: 2176
//DATA STRUCTURE: EXPERIMENT NO.1-FACTORIAL OF NUMBER

#include<stdio.h>
int fact(int x);
int main()
{
	int n,ans;
	printf("Enter the number:");
	scanf("%d",&n);
	ans=fact(n);
	printf("\nFACTORIAL OF THIS NUMBER:%d",ans);
}
int fact(int x)
{
	if(x==0)
	{
		return 1;
	}
	else
	{
		return x*fact(x-1);
	}
}


