//NAME: Sakshi Sharad Gaikwad
//URN: 1022032021
//ROLL NO: 2176
//DATA STRUCTURE: EXPERIMENT NO.1-TOWER OF HANOI

#include<stdio.h>
void toh(int x,char source,char dest,char temp);
int count;

int main()
{
	int x;
	printf("Enter the number of Disk:");
	scanf("%d",&x);
	count=0;
	toh1(x,'A','B','C');
	printf("\nTotal number of moves:%d",count);
}

void toh1(int x, char source,char dest,char temp)
{
	
	if(x>0)                                           //TERMINATING CONDITION
	{
		toh1(x-1,source,temp,dest);
		printf("\n MOVE %d FROM TOWER %c TO TOWER %c",x,source,dest);
		count++;
		toh1(x-1,temp,dest,source);
	}
}

